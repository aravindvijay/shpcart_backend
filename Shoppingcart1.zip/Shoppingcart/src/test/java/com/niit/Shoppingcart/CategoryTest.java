package com.niit.Shoppingcart;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.Shopcart.model.Category;
import com.niit.Shopcart.model.CategoryDAO;

public class CategoryTest {
	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		
		context.scan("com.niit.Shopcart");
		context.refresh();
		
		CategoryDAO categoryDAO = (CategoryDAO) context.getBean("categoryDAO");
		
		Category category = (Category) context.getBean("category");
		
	
		category.setCat_id("222");
		category.setCat_name("sony");
		category.setCat_des("desgh");
		
//		
		 categoryDAO.delete("232");
//		

//		categoryDAO.saveOrUpdate(category);
		
	}

}


