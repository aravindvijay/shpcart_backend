package com.niit.Shopcart.model;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("categoryDAO")
public class CategoryDAOImpl implements CategoryDAO {

	
	@Autowired
	private SessionFactory sessionFactory;
	public CategoryDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	@Transactional
	public List<Category> list() {
		@SuppressWarnings("unchecked")
		List<Category> listCategory = (List<Category>)
		        sessionFactory.getCurrentSession()
				.createCriteria(Category.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
				return listCategory;
		
	}
    @Transactional
	public Category get(String Cat_id) {
		String hq1 = "from Category when id="+"'"+Cat_id+"'";
		Query query = (Query) sessionFactory.getCurrentSession().createQuery(hq1);
		List<Category> listCategory = (List<Category>) query.getResultList();
	if (listCategory != null && !listCategory.isEmpty())
	{return listCategory.get(0);}	
	return null;
	}
   @Transactional
   public void saveOrUpdate(Category category) {
	   sessionFactory.getCurrentSession().saveOrUpdate(category);
		
	}
   
  
		@Transactional
		public void delete(String cat_id) {
			Category CategoryToDelete = new Category();
			CategoryToDelete.setCat_id(cat_id);
			sessionFactory.getCurrentSession().delete(CategoryToDelete);
		}
		
	
}
