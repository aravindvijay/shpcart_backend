package com.niit.Shopcart.model;

import java.util.List;

public interface CategoryDAO {

	
	public List<Category> list ();
	public Category get (String Cat_id);
	public void saveOrUpdate(Category category);
	public void delete (String Cat_name);
}
