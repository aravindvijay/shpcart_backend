package com.niit.Shopcart.model;

import java.util.List;

public interface SupplierDAO {
	public List<Supplier> list ();
	public Supplier get (String id);
	public void saveOrUpdate(Supplier supplier);
	public void delete (String name);
}
