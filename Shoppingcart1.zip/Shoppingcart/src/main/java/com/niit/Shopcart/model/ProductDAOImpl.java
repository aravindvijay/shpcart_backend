package com.niit.Shopcart.model;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("productDAO")
public class ProductDAOImpl implements ProductDAO {

	
	@Autowired
	private SessionFactory sessionFactory;
	public ProductDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	@Transactional
	public List<Product> list() {
		@SuppressWarnings("unchecked")
		List<Product> listProduct = (List<Product>)
		        sessionFactory.getCurrentSession()
				.createCriteria(Product.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
				return listProduct;
		
	}
	
    @Transactional
	public Product get(String id) {
		String hq1 = "from Product where id="+"'"+id +"'";
		Query query = (Query) sessionFactory.getCurrentSession().createQuery(hq1);
		List<Product> listProduct = (List<Product>) query.getResultList();
	if (listProduct != null && !listProduct.isEmpty())
	{return listProduct.get(0);}	
	return null;
	}
    
   @Transactional
   public void saveOrUpdate(Product product) {
	   sessionFactory.getCurrentSession().saveOrUpdate(product);
		
	}
    @Transactional
	public void delete(String id) {
    	Product ProductToDelete = new Product();
    	ProductToDelete.setId(id);
	
		
	}
}
