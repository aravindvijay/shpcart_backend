package com.niit.Shopcart.model;

import java.util.List;

public interface ProductDAO {
	public List<Product> list ();
	public Product get (String id);
	public void saveOrUpdate(Product product);
	public void delete (String name);
}
