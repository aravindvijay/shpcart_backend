package com.niit.Shoppingcart;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.Shopcart.model.Product;
import com.niit.Shopcart.model.ProductDAO;

public class ProductTest {
	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		
		context.scan("com.niit.Shopcart");
		context.refresh();
		
		ProductDAO productDAO = (ProductDAO) context.getBean("productDAO");
		
		Product product = (Product) context.getBean("product");
		
	
		product.setId("123");
		product.setName("sony");
		product.setDescription("desgh");
		product.setPrice(1000);

		productDAO.saveOrUpdate(product);
	}

}


